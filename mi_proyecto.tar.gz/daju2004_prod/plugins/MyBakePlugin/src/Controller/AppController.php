<?php

namespace MyBakePlugin\Controller;

use App\Controller\AppController as BaseController;

class AppController extends BaseController
{

}
